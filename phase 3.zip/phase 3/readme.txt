

File structure:
		-Project
			-images
				//contains all images used
			-process
				-covid_center_process.php
				-config.php
				-process.php
			-index.php
			-covid_test_center.php
			-location.php
			-symptoms.php

Development Platform:
	-PHP
	-HTML
	-CSS
	-Bootstrap
	-Javascript
	-MYSQL

this project was developed using ICEcoder





Running Project:
visit:
http://35.231.112.152/Project

navigate to "COVID TEST CENTER" for finding near by test centers
navigate to "SYMPTOMS" page to check details of diseases
navigate to location to page to find location and make an appointment
			